#include <iostream>
#include <string>
#include <fstream>
#include <fcntl.h>
#include <unistd.h>
#include <GL/glut.h>
#include <fstream>
#include "EasyBMP/EasyBMP.h"
using namespace std;

// Formato RGB de 2 bytes para SSE
const int global_pixelCharNumber = 2;
const int global_colorOnLow = false;

typedef unsigned char pixelColorMatrix;
typedef signed long pointCoordMatrix;

// Prepare los parametros de la ventana
char titulo_Bitmap[] = "Visualizador de Imagenes en Formato de Bitmaps";
char titulo_Vectorial[] = "Visualizador de Imagenes en Formato Vectorial";
int ventana_largo = 0;
int ventana_altura = 0;

// Parametros para imagenes en formato de bitmaps
int foto_largo;
int foto_altura;
int foto_memsize;
pixelColorMatrix* pSource_R;
pixelColorMatrix* pSource_G;
pixelColorMatrix* pSource_B;
pixelColorMatrix* pDest_R;
pixelColorMatrix* pDest_G;
pixelColorMatrix* pDest_B;

// Parametros para imagenes en formato de SVG
int origen_x;
int origen_y;
int numeroFiguras;
int numeroPuntosPorFigura[8];
pointCoordMatrix* cSource_x;
pointCoordMatrix* cSource_y;
pointCoordMatrix* cDest_x;
pointCoordMatrix* cDest_y;

// Convierte ( x , y ) en su equivalente ( k ) 
int celda(int x, int y){
	return (x*(foto_altura) + y);
}
// Procesamiento de texto 2D
void dibujeString(float x, float y, void *font, char* string)
{  
	glColor3ub(0, 0, 0); 
	glRasterPos2f(x, y);
	for (char* c = string; *c != '\0'; c++) {
		glutBitmapCharacter(font, *c);
	}
}

// Pide devolver callblack mediante puntero nulo
void renderizarGraficosVectoriales(void)
{
	// Funciones predeterminadas de renderizado
    glClearColor(1.0,1.0,1.0,1.0);
    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, ventana_largo, ventana_altura, 0);
    
    // Dibuje hileras
    dibujeString(20,26, GLUT_BITMAP_HELVETICA_18, "Grafico Original:");
    dibujeString(40 + ventana_largo/2,26, GLUT_BITMAP_HELVETICA_18, "Grafico Transformado:");
    
    // Dibuje los bordes
    glBegin(GL_LINES);
    glColor3ub(0,0,0);
    glVertex2i(ventana_largo/2,0);
	glVertex2i(ventana_largo/2,ventana_altura);
	
	// Lineas de origen
	glColor3ub(128,0,0);
	glVertex2i(0,ventana_altura/2);
	glVertex2i(ventana_largo,ventana_altura/2);
	
	glColor3ub(128,0,0);
	glVertex2i(ventana_largo/4,0);
	glVertex2i(ventana_largo/4,ventana_altura);
	
	glColor3ub(128,0,0);
	glVertex2i(ventana_largo/2 + ventana_largo/4,0);
	glVertex2i(ventana_largo/2 + ventana_largo/4,ventana_altura);
	
	// Termine
	glEnd();
	
	// Renderize TODAS las figuras, una por una
	int memIt = 0;
	int origen_x_render;
	int origen_y_render;
	for(int f=0; f<numeroFiguras; f++){
	
		glBegin(GL_LINES);
		glColor3ub(0,0,0);
		
		for(int i=0; i<numeroPuntosPorFigura[f]; i++){
		
			// Mapeo de las coordenas con respecto a la ventana vectorial
			origen_x_render = ventana_largo/4;
			origen_y_render = ventana_altura/2;
			
			// Sistema de puntos en pantalla
			int p1, p2;
			
			// Evalue el caso final, donde el ultimo punto se conecta al primero
			if(i == numeroPuntosPorFigura[f]-1){
				p1 = memIt;
				p2 = memIt - (numeroPuntosPorFigura[f]-1);
			}else{
				p1 = memIt;
				p2 = memIt+1;
			}
			
			glVertex2i(origen_x_render+cSource_x[p1],origen_y_render-cSource_y[p1]);
			glVertex2i(origen_x_render+cSource_x[p2],origen_y_render-cSource_y[p2]);
			
			origen_x_render = ventana_largo/2 + ventana_largo/4;
			glVertex2i(origen_x_render+cSource_x[p1],origen_y_render-cSource_y[p1]);
			glVertex2i(origen_x_render+cSource_x[p2],origen_y_render-cSource_y[p2]);
			memIt++;
		}
		
		glEnd();
	}
	
    // Termine el dibujado
    glFlush();
}

// Pide devolver callblack mediante puntero nulo
void renderizarGraficosBMP(void)
{
	// Funciones predeterminadas de renderizado
    glClearColor(1.0,1.0,1.0,1.0);
    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, ventana_largo, ventana_altura, 0);
    
    // Dibuje hileras
    dibujeString(20,26, GLUT_BITMAP_HELVETICA_18, "Imagen Original:");
    dibujeString(40+foto_largo,26, GLUT_BITMAP_HELVETICA_18, "Imagen Post-Efecto:");
    
    // Dibuje todos los pixeles
    glBegin(GL_POINTS);
    for(int y = 0; y < foto_altura; y++){
		for(int x = 0; x < foto_largo; x++){
			glColor3ub(pSource_R[celda(x,y)],pSource_G[celda(x,y)],pSource_B[celda(x,y)]);
			glVertex2i(20 + x, 40 + y);
			glColor3ub(pDest_R[celda(x,y)],pDest_G[celda(x,y)],pDest_B[celda(x,y)]);
			glVertex2i(40 + x +foto_largo, 40 + y);
		}
	}
    
    // Termine el dibujado
    glEnd();
    glFlush();
}

// Funciones de manejo de memoria de bitmaps
void alocarMemoriaContigua_BMP(int largo, int altura){
	foto_memsize = largo*altura;
	pSource_R = new pixelColorMatrix[foto_memsize]();
	pSource_G = new pixelColorMatrix[foto_memsize]();
	pSource_B = new pixelColorMatrix[foto_memsize]();
	pDest_R = new pixelColorMatrix[foto_memsize]();
	pDest_G = new pixelColorMatrix[foto_memsize]();
	pDest_B = new pixelColorMatrix[foto_memsize]();
}

// Carga los pixeles de bitmaps
void cargarPixeles_BMP(BMP imagen){
	for( int y=0 ; y < imagen.TellHeight(); y++){
		for( int x=0 ; x < imagen.TellWidth() ; x++){
			pSource_R[celda(x,y)] = imagen(x,y)->Red;
			pDest_R[celda(x,y)] = imagen(x,y)->Red;
			pSource_G[celda(x,y)] = imagen(x,y)->Green;
			pDest_G[celda(x,y)] = imagen(x,y)->Green;
			pSource_B[celda(x,y)] = imagen(x,y)->Blue;
			pDest_B[celda(x,y)] = imagen(x,y)->Blue;
		}
	}	
}

// Libera la memoria de bitmaps
void liberar_BMP(){
	delete[] pSource_R;
	delete[] pSource_G;
	delete[] pSource_B;
	delete[] pDest_R;
	delete[] pDest_G;
	delete[] pDest_B;
}

// Funciones de manejo de memoria de graficos vectoriales
void alocarMemoriaContigua_VECT(int puntos){
	cSource_x = new pointCoordMatrix[puntos]();
	cSource_y = new pointCoordMatrix[puntos]();
	cDest_x = new pointCoordMatrix[puntos]();
	cDest_y = new pointCoordMatrix[puntos]();
}

// Libera la memoria de graficos vectorial
void liberar_VECT(){
	delete[] cSource_x;
	delete[] cSource_y;
	delete[] cDest_x;
	delete[] cDest_y;
}


// Comprueba si existe el archivo
bool existeArchivo(const std::string& archivo) {
    ifstream f(archivo.c_str());
    return f.good();
}

// Convierte el dato a hilera de chars para el kernel
unsigned char* pixelToCharString(pixelColorMatrix* matrix, int pixels, int bytesPerPixel, bool colorOnLow){
	unsigned char* msg = new unsigned char[bytesPerPixel*pixels];	
	for(int i=0; i<pixels; i++){
		for(int j=0; j<bytesPerPixel; j++){
			msg[(bytesPerPixel*i)+j] = 0;
		}
		
		// Nos permite escojer el endianness con solo un true/false
		if(colorOnLow){
			msg[(bytesPerPixel*i)+(bytesPerPixel-1)] = matrix[i];
		}else{
			msg[(bytesPerPixel*i)] = matrix[i];
		}
	}
	return msg;
}

// Convierte el dato de hilera a pixeles
void charStringToPixel(unsigned char* msg, pixelColorMatrix* matrix, int pixels, int bytesPerPixel, bool colorOnLow){
	if(colorOnLow){
		for(int i=0; i<pixels; i++){
			matrix[i] = msg[(bytesPerPixel*i)+(bytesPerPixel-1)];
		}
	}else{
		for(int i=0; i<pixels; i++){
			matrix[i] = msg[(bytesPerPixel*i)];
		}
	}
}


// Llama al modulo para aplicar algun efecto en bitmaps
int gMatrixDeviceBitmap(pixelColorMatrix* srcR, pixelColorMatrix* srcG, pixelColorMatrix* srcB, pixelColorMatrix* dstR, pixelColorMatrix* dstG, pixelColorMatrix* dstB, int memsize, int efecto){
	
	// Abre el dispositivo primeramente
	int fd;
	fd = open("/dev/GMatrixDeviceDriver", O_RDWR);
	if (fd < 0){
		cout << "Ha ocurrido un error desde el userspace para abrir el dispositivo." << endl;
		return 1;
	}
	
	cout << "Se ha abierto correctamente el device driver." << endl;
		
	// Construye las matrices en formato de MENSAJE 
	unsigned char* buffer_r = pixelToCharString(srcR, memsize, global_pixelCharNumber, global_colorOnLow);
	unsigned char* buffer_g = pixelToCharString(srcG, memsize, global_pixelCharNumber, global_colorOnLow);
	unsigned char* buffer_b = pixelToCharString(srcB, memsize, global_pixelCharNumber, global_colorOnLow);
	unsigned char* return_r = pixelToCharString(srcR, memsize, global_pixelCharNumber, global_colorOnLow);
	unsigned char* return_g = pixelToCharString(srcG, memsize, global_pixelCharNumber, global_colorOnLow);
	unsigned char* return_b = pixelToCharString(srcB, memsize, global_pixelCharNumber, global_colorOnLow);
	
	
	// Construya el efecto en formato de MENSAJE
	char buffer_param[3]; 
	buffer_param[0] = '1';
	buffer_param[1] = (char)(48 + efecto);
	buffer_param[2] = 0;
	
	// Indique que efecto aplicaremos
	cout << "Ahora se aplicara el efecto/transformacion con el ID " << buffer_param << endl;
	
	// Ahora escriba los parametros iniciales
	write(fd, buffer_param, 2); 
	
	// Envie los bitmaps
	write(fd, buffer_r, memsize*global_pixelCharNumber); 
	write(fd, buffer_g, memsize*global_pixelCharNumber); 
	write(fd, buffer_b, memsize*global_pixelCharNumber); 
	
	// Reciba los bitmaps modificados
	read(fd, return_r, memsize*global_pixelCharNumber); 
	read(fd, return_g, memsize*global_pixelCharNumber);
	read(fd, return_b, memsize*global_pixelCharNumber);
	
	// Ahora reconviertalos a formato de pixeles
	charStringToPixel(return_r, pDest_R, memsize, global_pixelCharNumber, global_colorOnLow);
	charStringToPixel(return_g, pDest_G, memsize, global_pixelCharNumber, global_colorOnLow);
	charStringToPixel(return_b, pDest_B, memsize, global_pixelCharNumber, global_colorOnLow);
	
	delete[] buffer_r;
	delete[] buffer_g;
	delete[] buffer_b;
	delete[] return_r;
	delete[] return_g;
	delete[] return_b;
	
	close(fd);
	return 0;
}

// Llama al modulo para aplicar algun efecto en vectorial
void gMatrixDeviceVector(pointCoordMatrix* srcX, pointCoordMatrix* srcY, pointCoordMatrix* dstX, pointCoordMatrix* dstY, int transformacion){
	
}

// Instruccion de entrada
int main(int argc, char** argv)
{
	cout << "GMatrix Project " << endl;
	cout << "Escriba que tipo de filtros desea comenzar a utilizar: \n0 para transformaciones vectoriales \n1 para efectos en bitmaps (BMP)" << endl;
	int tipo;
	cin >> tipo;
	
	bool cargoExitosamente = false;
	string nombre_archivo;
	
	if(tipo!=0){
		
		// Cargue el archivo en formato de bitmap
		BMP archivo_bitmap;
		while(!cargoExitosamente){
			cout << "\nEscriba el nombre del archivo BMP que desea cargar, incluya extension." << endl;
			cin >> nombre_archivo;
			if (!existeArchivo(nombre_archivo)){
				cout << "\nEl archivo no existe, o no es un archivo de Bitmap BMP. Reintentelo.";
			}else{
				cargoExitosamente = true;
			}
		}
		
		// Cargue los datos iniciales del archivo de bitmap
		archivo_bitmap.ReadFromFile(nombre_archivo.c_str());
		foto_largo = archivo_bitmap.TellWidth();
		foto_altura = archivo_bitmap.TellHeight();
		cout << endl << "Se ha cargado el archivo de bitmap exitosamente." << endl;
		cout << "Resolucion detectada: " << foto_largo << "x" << foto_altura << endl;
		
		// Cree bloques de memoria contigua necesario para el bitmap
		alocarMemoriaContigua_BMP(foto_largo,foto_altura);
		cargarPixeles_BMP(archivo_bitmap);
		
		// Ahora ajuste la ventana que se creara para que tenga el tamaño correcto
		ventana_largo = foto_largo*2 + 60;
		ventana_altura = foto_altura + 80;
		
		// Pidale al usuario que efecto desea aplicar
		cout << "\nEscriba que efecto de bitmaps desea aplicarle a la foto.\n0 = Escala de Grises\n1 = Color Sepia\n2 = Invertir Negativo\n";
		int efecto ;
		cin >> efecto;
		
		// Inicie OpenGL usando freeglut como API
		glutInit(&argc, argv);
		glutInitDisplayMode(GLUT_SINGLE); 
		int posicionCentralX = ((glutGet(GLUT_SCREEN_WIDTH)-ventana_largo)/2);
		int posicionCentralY = ((glutGet(GLUT_SCREEN_HEIGHT)-ventana_altura)/2);
		glutInitWindowSize(ventana_largo, ventana_altura);
		glutInitWindowPosition(posicionCentralX, posicionCentralY);
		glutCreateWindow(titulo_Bitmap);
		
		// LLame al modulo para que realice el puente de comunicación y devuelva una matriz con un efecto aplicado
		if (gMatrixDeviceBitmap(pSource_R, pSource_G, pSource_B, pDest_R, pDest_G, pDest_B, foto_memsize, efecto)>=0){
			glutDisplayFunc(renderizarGraficosBMP);
			glutMainLoop();
		}
		
		// Termine
		liberar_BMP();
		
		
	}else{
		
		// Cargue el archivo en formato vectorial
		
		while(!cargoExitosamente){
			cout << "\nEscriba el nombre del archivo vectorial que desea cargar, incluya extension." << endl;
			cin >> nombre_archivo;
			
			if (!existeArchivo(nombre_archivo)){
				cout << "\nEl archivo no existe, o no es un archivo de vectorial valido. Reintentelo.";
			}else{
				ifstream archivo_vec(nombre_archivo.c_str(), std::ios_base::in);
				cargoExitosamente = true;
				
				// Cargue los datos iniciales del archivo vectorial
				archivo_vec >> origen_x;
				archivo_vec >> origen_y;
				archivo_vec >> numeroFiguras;
				cout << endl << "Se ha cargado el archivo vectorial exitosamente." << endl;
				cout << "Coordenada del punto de origen: (" << origen_x << "," << origen_y << ")" << endl;
				cout << "Numero de figuras en el archivo vectorial: " << numeroFiguras << endl;
				
				// Reserve 32 puntos MAXIMOS para cada figura
				alocarMemoriaContigua_VECT(32*numeroFiguras);
				int it = 0;
				for(int f=0; f<numeroFiguras; f++){
					archivo_vec >> numeroPuntosPorFigura[f];
					cout << "Figura #" << f << ": ";
					int coord_x;
					int coord_y;
					for(int i=0; i<numeroPuntosPorFigura[f]; i++){
						archivo_vec >> coord_x;
						archivo_vec >> coord_y;
						coord_x = coord_x - origen_x;
						coord_y = coord_y - origen_y;
						cSource_x[it] = coord_x;
						cSource_y[it] = coord_y;
						cDest_x[it] = coord_x;
						cDest_y[it] = coord_y;
						cout << "(" << cSource_x[it] << "," << cSource_y[it] << ")";
						it++;
					}
					cout << endl;
				}
				
				// Ahora ajuste la ventana que se creara para que tenga el tamaño correcto
				ventana_largo = 1000;
				ventana_altura = 600;
				
				// Pidale al usuario que efecto desea aplicar
				cout << "\nEscriba que transformacion vectorial desea aplicarle al grafico.\n0 = Rotacion\n1 = Traslacion\n2 = Espejo\n";
				int transformacion ;
				cin >> transformacion;
				
				// Inicie OpenGL usando freeglut como API
				glutInit(&argc, argv);
				glutInitDisplayMode(GLUT_SINGLE); 
				int posicionCentralX = ((glutGet(GLUT_SCREEN_WIDTH)-ventana_largo)/2);
				int posicionCentralY = ((glutGet(GLUT_SCREEN_HEIGHT)-ventana_altura)/2);
				glutInitWindowSize(ventana_largo, ventana_altura);
				glutInitWindowPosition(posicionCentralX, posicionCentralY);
				glutCreateWindow(titulo_Vectorial);
				
				// LLame al modulo para que realice el puente de comunicación y devuelva una matriz con un efecto aplicado
			    gMatrixDeviceVector(cSource_x, cSource_y, cDest_x, cDest_y, transformacion);
				
				// Defina las funciones del usuario
				glutDisplayFunc(renderizarGraficosVectoriales);
				glutMainLoop();
				
				//Termine
				liberar_VECT();
				archivo_vec.close();
		
			}
		}
		
		
	}
	
    return 0;
}
