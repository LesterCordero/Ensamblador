#include <linux/init.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Steven, Daniela y Lester");
MODULE_DESCRIPTION("Modulo Device Driver");
MODULE_VERSION("0.05");

// Misc
//static char msg_buffer[MSG_BUFFER_LEN];
//static char *msg_ptr;

#define nombre_device_driver    "GMatrixDeviceDriver"
#define classname_device_driver "GMatrixDeviceDriverClass"

// Identificador del modulo y candado de acceso
static int device_id;
static int device_syslock = 0;

// Punteros del device driver
static struct class*  device_driver_class  = NULL; 
static struct device* device_driver_ptr    = NULL; 

// Se llama cuando se lee en nuestro dispositivo (es decir, el device driver lee desde el user space)
static ssize_t device_driver_recibir(struct file *flip, char *buffer, size_t len, loff_t *offset) {
	
	return 0;
}

// Se llama cuando se escribe en nuestro dispositivo (es decir, el kernel escribe en el user space)
static ssize_t device_driver_enviar(struct file *flip, const char *buffer, size_t len, loff_t *offset) {

	return 0;
}

// Se llama cuando se abre el dispositivo (se abre el archivo en /dev/)
static int device_driver_abierto(struct inode *inode, struct file *file) {
	device_syslock++;
	printk(KERN_INFO "GMatrix Device Driver: Dispositivo abierto desde el userspace. \n");
	
	return 0;
}

// Se llama cuando se cierra el dispositivo (se cierra el archivo en /dev/)
static int device_driver_liberar(struct inode *inode, struct file *file) {
	device_syslock--;
	printk(KERN_INFO "GMatrix Device Driver: Dispositivo cerrado desde el userspace. \n");
	
	return 0;
}

// Punteros a las funciones del device driver
static struct file_operations operaciones_principales = {
	.read = device_driver_recibir,
	.write = device_driver_enviar,
	.open = device_driver_abierto,
	.release = device_driver_liberar
};

// Funcion de carga del modulo al Kernel
static int __init device_driver_cargado(void) {
	 
	// Registre el identificador del modulo
	device_id = register_chrdev(0, nombre_device_driver, &operaciones_principales);
	 
	if (device_id < 0) {
		printk(KERN_ALERT "GMatrix Device Driver: No se pudo cargar el dispositivo. \n");
		return device_id;
	}else{
		printk(KERN_INFO "GMatrix Device Driver: Modulo ha sido cargado correctamente. (ID: %d) \n", device_id);
	}
	
	// Cree la clase dinamica que contendra al modulo
	device_driver_class = class_create(THIS_MODULE, classname_device_driver);
	if(IS_ERR(device_driver_class)){
		unregister_chrdev(device_id, nombre_device_driver);
		printk(KERN_ALERT "GMatrix Device Driver: Error al crear la clase del dispositivo. \n");
		return PTR_ERR(device_driver_class);
	}
	printk(KERN_INFO "GMatrix Device Driver: Clase del dispositivo creada correctamente. \n");
	
	// Ahora si, cree el archivo del dispositivo en /dev/ ahora que ya tenemos todo lo necesario
	device_driver_ptr = device_create(device_driver_class, NULL, MKDEV(device_id, 0), NULL, nombre_device_driver);
	if (IS_ERR(device_driver_ptr)){
		class_destroy(device_driver_class);
		unregister_chrdev(device_id, nombre_device_driver);
		printk(KERN_ALERT "GMatrix Device Driver: Error al crear el dispositivo. \n");
		return PTR_ERR(device_driver_ptr);
	}
	printk(KERN_INFO "GMatrix Device Driver: Dispositivo listo para utilizar desde el userspace. \n");
	return 0;
}

// Funcion de descarga del Kernel
static void __exit device_driver_descargado(void) {
	device_destroy(device_driver_class, MKDEV(device_id, 0));     
	class_unregister(device_driver_class);                          
	class_destroy(device_driver_class);                             
	unregister_chrdev(device_id, nombre_device_driver);
	printk(KERN_INFO "GMatrix Device Driver: Modulo ha sido descargado correctamente. (ID: %d) \n", device_id);
}

// Punteros a las funciones de carga y descarga
module_init(device_driver_cargado);
module_exit(device_driver_descargado);
