#include <linux/module.h>
MODULE_LICENSE("GPL-2");

extern void _asm_E1(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB);
extern void _asm_E2(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB);
extern void _asm_E3(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB);
extern void _asm_T1(char* srcX, char* srcY, char* dstX, char* dstY, int p1, int p2, int xfrom, int yfrom, int angle);
extern void _asm_T2(char* srcX, char* srcY, char* dstX, char* dstY, int p1, int p2, int xdisplace, int ydisplace);
extern void _asm_T3(char* srcX, char* srcY, char* dstX, char* dstY, int p1, int p2, int x1, int y1, int x2, int y2);

//De arreglo de 4 chars a entero de nuevo
int bytesToInt(char* bytes){
	int num = (int)((unsigned char)(bytes[3]) << 24 |
    (unsigned char)(bytes[2]) << 16 | 
    (unsigned char)(bytes[1]) << 8 | 
    (unsigned char)(bytes[0]));
    return num;
}

// Convierte un entero en un arreglo de 4 chars
void intToBytes(int n, char* bytes){
	bytes[3] = (n >> 24) & 0xFF;
	bytes[2] = (n >> 16) & 0xFF;
	bytes[1] = (n >> 8) & 0xFF;
	bytes[0] = n & 0xFF;
}

static void aplicar_escala_de_grises(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB){
	_asm_E1(srcR, srcG, srcB, dstR, dstG, dstB);
	printk(KERN_INFO "GMatrix Device: Se ha aplicado escala de grises a una imagen de bitmaps.");
}

static void aplicar_sepia(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB){
	_asm_E2(srcR, srcG, srcB, dstR, dstG, dstB);
	printk(KERN_INFO "GMatrix Device: Se ha aplicado color sepia a una imagen de bitmaps.");
}

static void aplicar_negativo(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB){
	_asm_E3(srcR, srcG, srcB, dstR, dstG, dstB);
	printk(KERN_INFO "GMatrix Device: Se ha aplicado negativo a una imagen de bitmaps.");
}

static void aplicar_rotacion(char* srcX, char* srcY, char* dstX, char* dstY, int p1, int p2, int xfrom, int yfrom, int angle){
	_asm_T1(srcX, srcY, dstX, dstY, p1, p2, xfrom, yfrom, angle);
	printk(KERN_INFO "GMatrix Device: Se ha aplicado rotacion a una figura vectorial.");
}

static void aplicar_traslacion(char* srcX, char* srcY, char* dstX, char* dstY, int p1, int p2, int xdisplace, int ydisplace){
	_asm_T2(srcX, srcY, dstX, dstY, p1, p2, xdisplace, ydisplace);
	printk(KERN_INFO "GMatrix Device: Se ha aplicado traslacion a una figura vectorial");
}

static void aplicar_espejo(char* srcX, char* srcY, char* dstX, char* dstY, int p1, int p2, int x1, int y1, int x2, int y2){
	 //_asm_T3(srcX, srcY, dstX, dstY, p1, p2, x1, y1, x2, y2);
	 printk(KERN_INFO "GMatrix Device: Se ha aplicado espejo a una figura vectorial.");
}

// Exporte los simbolos de los efectos
EXPORT_SYMBOL(aplicar_escala_de_grises);
EXPORT_SYMBOL(aplicar_sepia);
EXPORT_SYMBOL(aplicar_negativo);
EXPORT_SYMBOL(aplicar_rotacion);
EXPORT_SYMBOL(aplicar_traslacion);
EXPORT_SYMBOL(aplicar_espejo);
EXPORT_SYMBOL(_asm_E1);
EXPORT_SYMBOL(_asm_E2);
EXPORT_SYMBOL(_asm_E3);
EXPORT_SYMBOL(_asm_T1);
EXPORT_SYMBOL(_asm_T2);
EXPORT_SYMBOL(_asm_T3);

// Convierte de entero a 4 bytes y viceversa, usando el low Endianness 
// Estas deben ser iguales de kernel y dispositivo, para evitar problemas
EXPORT_SYMBOL(intToBytes);
EXPORT_SYMBOL(bytesToInt);

static int __init device_cargado(void) {
	printk(KERN_INFO "GMatrix Device: Dispositivo listo para utilizar desde el driver. \n");
	return 0;
}

static void __exit device_descargado(void) {
	printk(KERN_INFO "GMatrix Device: Dispositivo ha sido descargado correctamente.\n");
}

// Punteros a las funciones de carga y descarga
module_init(device_cargado);
module_exit(device_descargado);
