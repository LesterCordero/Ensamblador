#include <iostream>
#include <string>
#include <GL/glut.h>
#include <fstream>
#include "EasyBMP/EasyBMP.h"
using namespace std;

// Formato RGB Mejorado de 16 bits
typedef unsigned short pixelColorMatrix;

// Prepare los parametros de la ventana
char titulo[] = "Visualizador de Imagenes en BITMAP";
int ventana_largo = 0;
int ventana_altura = 0;

// Parametros para imagenes en formato de SVG

// Parametros para imagenes en formato de bitmaps
int foto_largo;
int foto_altura;
int foto_memsize;
pixelColorMatrix* pSource_R;
pixelColorMatrix* pSource_G;
pixelColorMatrix* pSource_B;
pixelColorMatrix* pDest_R;
pixelColorMatrix* pDest_G;
pixelColorMatrix* pDest_B;

// Convierte ( x , y ) en su equivalente ( k ) 
int celda(int x, int y){
	return (x*(foto_altura) + y);
}
// Procesamiento de texto 2D
void dibujeString(float x, float y, void *font, char* string)
{  
	glColor3ub(0, 0, 0); 
	glRasterPos2f(x, y);
	for (char* c = string; *c != '\0'; c++) {
		glutBitmapCharacter(font, *c);
	}
}

// Pide devolver callblack mediante puntero nulo
void renderizar(void)
{
	// Cambie el color de fondo a RGBA(255,255,255,255)
    glClearColor(1.0,1.0,1.0,1.0);
    
    // Apliqueselo a el buffer de color de la ventana
    glClear(GL_COLOR_BUFFER_BIT);
    
    // Indique que es una proyeccion 2D
    glMatrixMode(GL_PROJECTION);
    
    // Cargue la identidad
    glLoadIdentity();
    gluOrtho2D(0, ventana_largo, ventana_altura, 0);
    
    // Dibuje hileras
    dibujeString(20,26, GLUT_BITMAP_HELVETICA_18, "Imagen Original:");
    dibujeString(40+foto_largo,26, GLUT_BITMAP_HELVETICA_18, "Imagen Post-Efecto:");
    
    // Cambie el color de dibujado
    glBegin(GL_POINTS);
    for(int x = 0; x < foto_largo; x++){
		for(int y = 0; y < foto_altura; y++){
			glColor3ub(pSource_R[celda(x,y)],pSource_G[celda(x,y)],pSource_B[celda(x,y)]);
			glVertex2i(20 + x, 40 + y);
			glVertex2i(40 + x +foto_largo, 40 + y);
		}
	}
    
    // Termine el dibujado
    glEnd();
    
    // Fuerza que los comandos de OpenGL sean finitos, y borra los buffers
    glFlush();
}

// Funciones de manejo de memoria
void alocarMemoriaContigua(int largo, int altura){
	foto_memsize = largo*altura;
	if((largo*altura)%16 != 0){
		int completeMultiplo16 = 16 - (largo*altura)%16;
		foto_memsize+= completeMultiplo16;
	}
	pSource_R = new pixelColorMatrix[foto_memsize]();
	pSource_G = new pixelColorMatrix[foto_memsize]();
	pSource_B = new pixelColorMatrix[foto_memsize]();
	pDest_R = new pixelColorMatrix[foto_memsize]();
	pDest_G = new pixelColorMatrix[foto_memsize]();
	pDest_B = new pixelColorMatrix[foto_memsize]();
}

// Carga los pixeles
void cargarPixelesDesdeArchivo(BMP imagen){
	for( int x=0 ; x < imagen.TellWidth() ; x++){
		for( int y=0 ; y < imagen.TellHeight(); y++){
			pSource_R[celda(x,y)] = imagen(x,y)->Red;
			pDest_R[celda(x,y)] = imagen(x,y)->Red;
			pSource_G[celda(x,y)] = imagen(x,y)->Green;
			pDest_G[celda(x,y)] = imagen(x,y)->Green;
			pSource_B[celda(x,y)] = imagen(x,y)->Blue;
			pDest_B[celda(x,y)] = imagen(x,y)->Blue;
		}
	}	
}

// Libera la memoria
void liberar(){
	delete[] pSource_R;
	delete[] pSource_G;
	delete[] pSource_B;
	delete[] pDest_R;
	delete[] pDest_G;
	delete[] pDest_B;
}

// Comprueba si existe el archivo
bool existeArchivo(const std::string& archivo) {
    ifstream f(archivo.c_str());
    return f.good();
}

// Llama al modulo para aplicar algun efecto en bitmaps
void gMatrixDeviceBitmap(pixelColorMatrix* sR, pixelColorMatrix* sG, pixelColorMatrix* sB, pixelColorMatrix* dR, pixelColorMatrix* dG, pixelColorMatrix* dB, int memsize, int efecto){

}

// Instruccion de entrada
int main(int argc, char** argv)
{

	cout << "Escriba que desea realizar \n0 = Transformacion SVG\n1 = Efecto en bitmap BMP" << endl;
	int tipo;
	cin >> tipo;
	
	if(tipo!=0){
		
		// Formato BITMAP
		string nombre_archivo;
		BMP archivo_bitmap;
		
		bool cargoExitosamente = false;
		while(!cargoExitosamente){
			cout << "\nEscriba el nombre del archivo BMP a cargar, incluya extension." << endl;
			cin >> nombre_archivo;
			
			if (!existeArchivo(nombre_archivo)){
				cout << "\nEl archivo no existe, o no es un archivo de Bitmap BMP. Repitalo.";
			}else{
				archivo_bitmap.ReadFromFile(nombre_archivo.c_str());
				cargoExitosamente = true;
			}
		}
		
		foto_largo = archivo_bitmap.TellWidth();
		foto_altura = archivo_bitmap.TellHeight();
		
		// Ahora ajuste la ventana que se creara para que tenga el tamaño correcto
		ventana_largo = foto_largo*2 + 60;
		ventana_altura = foto_altura + 80;
		
		// Aplique un efecto
		cout << "\nEscriba que efecto de bitmaps desea aplicarle a la foto.\n0 = Escala de Grises\n1 = Color Sepia\n2 = Invertir Negativo\n";
		int efecto ;
		cin >> efecto;
		
		// LLame al modulo para que realice el puente de comunicación y devuelva una matriz con un efecto aplicado
		gMatrixDeviceBitmap(pSource_R, pSource_R, pSource_R, pSource_R, pSource_R, pSource_R, foto_memsize, efecto);
		
		// Inicie OpenGL usando freeglut como API
		glutInit(&argc, argv);
		glutInitDisplayMode(GLUT_SINGLE); 
		int posicionCentralX = ((glutGet(GLUT_SCREEN_WIDTH)-ventana_largo)/2);
		int posicionCentralY = ((glutGet(GLUT_SCREEN_HEIGHT)-ventana_altura)/2);
		glutInitWindowSize(ventana_largo, ventana_altura);
		glutInitWindowPosition(posicionCentralX, posicionCentralY);
		glutCreateWindow(titulo);
		
		// Cree bloques de Memoria Contigua
		alocarMemoriaContigua(foto_largo,foto_altura);
		cargarPixelesDesdeArchivo(archivo_bitmap);
		
		// Defina las funciones del usuario
		glutDisplayFunc(renderizar);
		glutMainLoop();
		
		// Termine
		liberar();
		
		
	}else{
		
		// Formato SVG
		// Libreria QT trabaja con SVG
		// Investigar sobre QT
		
	}
	
    return 0;
}
