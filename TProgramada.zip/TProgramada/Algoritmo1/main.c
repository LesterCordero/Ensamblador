#include <stdio.h>
#include <string.h>
#define size 1000
extern void sumaRand(char* hilera, int semilla, int operacion);

int main(){
	
	// Parámetros básicos
	char hilera[size+1];
	int semilla = 545454;
	
	// Cree punteros iniciales
	FILE *archivo_original;
	FILE *archivo_encriptado;
	FILE *archivo_desencriptado;
	
	// Carge el archivo de entrada y salida en su respectivo modo
	archivo_original = fopen("liebre.txt","r");
	archivo_encriptado = fopen("liebre_protegido.txt","w+");
	archivo_desencriptado = fopen("liebre_desencriptado.txt","w");
		
	// Si no cargo los archivos entonces falle
	if(archivo_original == NULL || archivo_encriptado == NULL || archivo_desencriptado == NULL){
		printf("Error al cargar el archivo original o durante la creacion de los archivos de salida.\n");
		return -1;
	}
	
	printf("Se va a encriptar el archivo de prueba (Semilla:%i)\n",semilla);
	while(fgets(hilera, size+1, archivo_original) != NULL){
		if(strlen(hilera) >= size){
			printf("Error, pues al menos una linea contiene mas de 1000 bytes.\n");	
			printf("El programa ha terminado incorrectamente.\n");
			fclose(archivo_original);
			fclose(archivo_encriptado);
			fclose(archivo_desencriptado);
			return -1;
		}
		sumaRand(hilera, semilla, 0);
		fputs(hilera, archivo_encriptado);
	}
	
	printf("Se va a desencriptar el archivo ya encriptado previamente(Semilla:%i)\n",semilla);
	fseek(archivo_encriptado,0, SEEK_SET);
	while(fgets(hilera, size+1, archivo_encriptado) != NULL){
		sumaRand(hilera, semilla, 1);
		fputs(hilera, archivo_desencriptado);
	}
	
	printf("El programa ha terminado exitosamente.\n");
	
	fclose(archivo_original);
	fclose(archivo_encriptado);
	fclose(archivo_desencriptado);
	return 0;
		
}
