#include <linux/module.h>
MODULE_LICENSE("GPL");

static void aplicar_escala_de_grises(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB, int charNumbers){

		/* Recrear esto en ensamblador*/
		/* Usar este efecto como plantilla*/
		int i = 0;
		for(i = 0; i<charNumbers; i++){	
			short tmp;
			tmp = (srcR[(2*i)+0] << 8) | srcR[(2*i)+1];
			tmp += (srcG[(2*i)+0] << 8) | srcG[(2*i)+1];
			tmp += (srcB[(2*i)+0] << 8) | srcB[(2*i)+1];
			tmp /= 3;
			dstR[(2*i)+1] = tmp;
			dstG[(2*i)+1] = tmp;
			dstB[(2*i)+1] = tmp;
		}
		
}

static void aplicar_sepia(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB, int charNumbers){
	
}

static void aplicar_negativo(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB, int charNumbers){
	
}

// Exporte los simbolos
EXPORT_SYMBOL(aplicar_escala_de_grises);
EXPORT_SYMBOL(aplicar_sepia);
EXPORT_SYMBOL(aplicar_negativo);

static int __init device_cargado(void) {
	printk(KERN_INFO "GMatrix Device: Dispositivo listo para utilizar desde el driver. \n");
	return 0;
}


static void __exit device_descargado(void) {
	printk(KERN_INFO "GMatrix Device: Dispositivo ha sido descargado correctamente.\n");
}

// Punteros a las funciones de carga y descarga
module_init(device_cargado);
module_exit(device_descargado);
