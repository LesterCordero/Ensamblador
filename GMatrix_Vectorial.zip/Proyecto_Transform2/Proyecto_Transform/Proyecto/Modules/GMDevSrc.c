#include <linux/module.h>
MODULE_LICENSE("GPL-2");

extern void _asm_E1(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB);
extern void _asm_E2(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB);
extern void _asm_E3(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB);

extern void _asm_T1(char* srcX, char* srcY, char* dstX, char* dstY, int p1, int p2, int xfrom, int yfrom, int angle);
extern void _asm_T2(char* srcX, char* srcY, char* dstX, char* dstY, int p1, int p2, int xdisplace, int ydisplace);

//De arreglo de 4 chars a entero de nuevo
int bytesToInt(char* bytes){
	int a = (int)((unsigned char)(bytes[0]) << 24 |
    (unsigned char)(bytes[1]) << 16 | 
    (unsigned char)(bytes[2]) << 8 | 
    (unsigned char)(bytes[3]));
    return a;
}

// Convierte un entero en un arreglo de 4 chars
void intToBytes(int n, char* bytes){
	bytes[0] = (n >> 24) & 0xFF;
	bytes[1] = (n >> 16) & 0xFF;
	bytes[2] = (n >> 8) & 0xFF;
	bytes[3] = n & 0xFF;
}

static void aplicar_escala_de_grises(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB){
	_asm_E1(srcR, srcG, srcB, dstR, dstG, dstB);
}

static void aplicar_sepia(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB){
	_asm_E2(srcR, srcG, srcB, dstR, dstG, dstB);
}

static void aplicar_negativo(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB){
	_asm_E3(srcR, srcG, srcB, dstR, dstG, dstB);
}

static void aplicar_rotacion(char* srcX, char* srcY, char* dstX, char* dstY, int p1, int p2, int xfrom, int yfrom, int angle){
	//_asm_T1(srcX, srcY, dstX, dstY, it1, it2, xfrom, yfrom, angle);
	// pero esto si usa punto flotante
}

static void aplicar_traslacion(char* srcX, char* srcY, char* dstX, char* dstY, int p1, int p2, int xdisplace, int ydisplace){
	//_asm_T2(srcX, srcY, dstX, dstY, it1, it2, xdisplace, ydisplace);
	// RECREAR EN ENSAMBLADOR
	int k = 0;
	for(k = p1; k<=p2; k++){
		// De 4 chars, genere un int
		int tmpX = bytesToInt(&srcX[4*k]);
		int tmpY = bytesToInt(&srcY[4*k]);
		
		tmpX += xdisplace;
		tmpY += ydisplace;	
					
		// convierta ese nuevo int a 4 bytes
		char tmp2X[4];
		char tmp2Y[4];
		intToBytes(tmpX, tmp2X);
		intToBytes(tmpY, tmp2Y);
							
		// escriba esos 4 bytes en la matrix final de puntos X, Y
		dstX[4*k+0]=tmp2X[0];
		dstX[4*k+1]=tmp2X[1];
		dstX[4*k+2]=tmp2X[2];
		dstX[4*k+3]=tmp2X[3];
		dstY[4*k+0]=tmp2Y[0];
		dstY[4*k+1]=tmp2Y[1];
		dstY[4*k+2]=tmp2Y[2];
		dstY[4*k+3]=tmp2Y[3];
	}
	
}

// Exporte los simbolos
EXPORT_SYMBOL(aplicar_escala_de_grises);
EXPORT_SYMBOL(aplicar_sepia);
EXPORT_SYMBOL(aplicar_negativo);
EXPORT_SYMBOL(_asm_E1);
EXPORT_SYMBOL(_asm_E2);
EXPORT_SYMBOL(_asm_E3);

EXPORT_SYMBOL(aplicar_rotacion);
EXPORT_SYMBOL(aplicar_traslacion);
EXPORT_SYMBOL(_asm_T1);
EXPORT_SYMBOL(_asm_T2);

EXPORT_SYMBOL(intToBytes);
EXPORT_SYMBOL(bytesToInt);

static int __init device_cargado(void) {
	printk(KERN_INFO "GMatrix Device: Dispositivo listo para utilizar desde el driver. \n");
	return 0;
}

static void __exit device_descargado(void) {
	printk(KERN_INFO "GMatrix Device: Dispositivo ha sido descargado correctamente.\n");
}

// Punteros a las funciones de carga y descarga
module_init(device_cargado);
module_exit(device_descargado);
