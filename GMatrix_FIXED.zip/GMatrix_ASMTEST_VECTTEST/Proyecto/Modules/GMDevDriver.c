#include <linux/init.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#define nombre_device_driver    "GMatrixDeviceDriver"
#define classname_device_driver "GMatrixDeviceDriverClass"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Steven, Daniela y Lester");
MODULE_DESCRIPTION("Modulo Device Driver");
MODULE_VERSION("0.05");

// Funciones del Dispositivo
extern void aplicar_escala_de_grises(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB, int charNumbers);
extern void aplicar_sepia(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB, int charNumbers);
extern void aplicar_negativo(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB, int charNumbers);

// Identificador del modulo y candado de acceso
static int device_id;
static int device_syslock = 0;

// Punteros del device driver
static struct class*  device_driver_class  = NULL; 
static struct device* device_driver_ptr    = NULL; 

// Variables de llegada de mensajes de comunicacion
static char mensaje[2];
static int estado = 0;
static int transformacion = 0;
static int efecto = 0;

static int escrituras_pendientes = 0;
static int lecturas_pendientes = 0;

#define estado_parametros 0
#define estado_vectorial 1
#define estado_matricial 2

#define transformacion_rotacion 0
#define transformacion_traslacion 1
#define transformacion_espejo 2

#define efecto_grises 0
#define efecto_sepia 1
#define efecto_negativo 2

// Variables de datos matriciales y vectoriales
static unsigned char pSource_R[3000000];
static unsigned char pSource_G[3000000];
static unsigned char pSource_B[3000000];
static unsigned char pDest_R[3000000];
static unsigned char pDest_G[3000000];
static unsigned char pDest_B[3000000];
static unsigned char cSource_X[1000];
static unsigned char cSource_Y[1000];
static unsigned char cDest_X[1000];
static unsigned char cDest_Y[1000];
static int cOrigen_X;
static int cOrigen_Y;
static int cAngulo;

// Se llama cuando se lee en nuestro dispositivo (es decir, el device driver lee desde el user space)
static ssize_t device_driver_read(struct file *flip, char *buffer, size_t len, loff_t *offset) {
	
	if(estado == estado_matricial){
		
		if(escrituras_pendientes == 0){
			
			// En cada llamado envie al userspace las matrices ya con el efecto aplicado
			switch(lecturas_pendientes){
				case 3: 
					copy_to_user(buffer, pDest_R ,len); 
					printk(KERN_INFO "GMatrix Device Driver: El usuario esta leyendo del dispositivo bitmaps. Etapa 1/3");
					lecturas_pendientes--; 
					break;
				case 2: 
					copy_to_user(buffer, pDest_G ,len); 
					printk(KERN_INFO "GMatrix Device Driver: El usuario esta leyendo del dispositivo bitmaps. Etapa 2/3");
					lecturas_pendientes--; 
					break;
				case 1: 
					copy_to_user(buffer, pDest_B ,len);  
					printk(KERN_INFO "GMatrix Device Driver: El usuario esta leyendo del dispositivo bitmaps. Etapa 3/3");
					lecturas_pendientes--; 
					estado = estado_parametros;
					break;
			}
			
		}else{
			// Aun no completo el envio de las matrices originales, por lo que no puede enviar las matrices con el filtro
			printk(KERN_INFO "GMatrix Device Driver: No se puede enviar una respuesta si el dispostivo aun esta esperando matrices.");
					
		}
		
	}
	
	return 0;
		
}

// Se llama cuando se escribe en nuestro dispositivo (es decir, el kernel escribe en el user space)
static ssize_t device_driver_write(struct file *flip, const char *buffer, size_t len, loff_t *offset) {
	
	// EL kernel primero necesita saber que va recibir, asi que el espera primero los parametros en un primer call
	if (estado == estado_parametros){
		copy_from_user(mensaje, buffer, len);
		
		// Primero reciba los parametros y decodifique su instrucción
		char tipo        = mensaje[0];
		char filtro      = mensaje[1];
		
		// Digalo para proposito de debugging
		printk(KERN_INFO "GMatrix Device Driver: Se ha colocado el modo %c con el efecto/transformacion %c. \n", tipo, filtro);
		
		// Serán vectores
		if (tipo == '0'){
			
		// Serán bitmaps
		}else{
			
			estado = estado_matricial;
			escrituras_pendientes = 3;
			
			// Ahora con esto el modulo ya sabe que efecto va aplicar y que datos va recibir del usuario
			switch(filtro){
				case '0': efecto = efecto_grises; break;
				case '1': efecto = efecto_sepia; break;
				case '2': efecto = efecto_negativo; break;
			}
			
				
		}
		
	}else if (estado == estado_vectorial){
		
		// Transformaciones vectoriales
		
	}else if (estado == estado_matricial){
	
		// Efectos en bitmaps
		
		// Comienza a recibir en cada llamado una matriz de color
		switch(escrituras_pendientes){
			case 3: 
				copy_from_user(pSource_R, buffer, len); 
				escrituras_pendientes--; 
				printk(KERN_INFO "GMatrix Device Driver: El usuario esta escribiendo bitmaps al dispostivo. Etapa 1/3");
				break;
			case 2: 
				copy_from_user(pSource_G, buffer, len); 
				escrituras_pendientes--; 
				printk(KERN_INFO "GMatrix Device Driver: El usuario esta escribiendo bitmaps al dispostivo. Etapa 2/3");
				break;
			case 1: 
				copy_from_user(pSource_B, buffer, len); 
				escrituras_pendientes--; 
				printk(KERN_INFO "GMatrix Device Driver: El usuario esta escribiendo bitmaps al dispostivo. Etapa 3/3");
					
				// Cuando ya tiene todas las matrices, llame al otro modulo para hacer el efecto
				switch(efecto){
					case efecto_grises: aplicar_escala_de_grises(pSource_R, pSource_G, pSource_B, pDest_R, pDest_G, pDest_B, len); break;
					case efecto_sepia: aplicar_sepia(pSource_R, pSource_G, pSource_B, pDest_R, pDest_G, pDest_B, len); break;
					case efecto_negativo: aplicar_negativo(pSource_R, pSource_G, pSource_B, pDest_R, pDest_G, pDest_B, len); break;
				}
				
				lecturas_pendientes = 3; 
				break;
		}
			
	}
	
	return 0;
}

// Se llama cuando se abre el dispositivo (se abre el archivo en /dev/)
static int device_driver_abierto(struct inode *inode, struct file *file) {
	device_syslock++;
	printk(KERN_INFO "GMatrix Device Driver: Dispositivo abierto desde el userspace. \n");
	
	return 0;
}

// Se llama cuando se cierra el dispositivo (se cierra el archivo en /dev/)
static int device_driver_liberar(struct inode *inode, struct file *file) {
	device_syslock--;
	printk(KERN_INFO "GMatrix Device Driver: Dispositivo cerrado desde el userspace. \n");
	
	return 0;
}

// Punteros a las funciones del device driver
static struct file_operations operaciones_principales = {
	.read = device_driver_read,
	.write = device_driver_write,
	.open = device_driver_abierto,
	.release = device_driver_liberar
};

// Funcion de carga del modulo al Kernel
static int __init device_driver_cargado(void) {
	 
	// Registre el identificador del modulo
	device_id = register_chrdev(0, nombre_device_driver, &operaciones_principales);
	 
	if (device_id < 0) {
		printk(KERN_ALERT "GMatrix Device Driver: No se pudo cargar el dispositivo. \n");
		return device_id;
	}else{
		printk(KERN_INFO "GMatrix Device Driver: Modulo ha sido cargado correctamente. (ID: %d) \n", device_id);
	}
	
	// Cree la clase dinamica que contendra al modulo
	device_driver_class = class_create(THIS_MODULE, classname_device_driver);
	if(IS_ERR(device_driver_class)){
		unregister_chrdev(device_id, nombre_device_driver);
		printk(KERN_ALERT "GMatrix Device Driver: Error al crear la clase del dispositivo. \n");
		return PTR_ERR(device_driver_class);
	}
	printk(KERN_INFO "GMatrix Device Driver: Clase del dispositivo creada correctamente. \n");
	
	// Ahora si, cree el archivo del dispositivo en /dev/ ahora que ya tenemos todo lo necesario
	device_driver_ptr = device_create(device_driver_class, NULL, MKDEV(device_id, 0), NULL, nombre_device_driver);
	if (IS_ERR(device_driver_ptr)){
		class_destroy(device_driver_class);
		unregister_chrdev(device_id, nombre_device_driver);
		printk(KERN_ALERT "GMatrix Device Driver: Error al crear el dispositivo. \n");
		return PTR_ERR(device_driver_ptr);
	}
	printk(KERN_INFO "GMatrix Device Driver: Dispositivo listo para utilizar desde el userspace. \n");
	return 0;
}

// Funcion de descarga del Kernel
static void __exit device_driver_descargado(void) {
	device_destroy(device_driver_class, MKDEV(device_id, 0));     
	class_unregister(device_driver_class);                          
	class_destroy(device_driver_class);                             
	unregister_chrdev(device_id, nombre_device_driver);
	printk(KERN_INFO "GMatrix Device Driver: Modulo ha sido descargado correctamente. (ID: %d) \n", device_id);
}

// Punteros a las funciones de carga y descarga
module_init(device_driver_cargado);
module_exit(device_driver_descargado);
