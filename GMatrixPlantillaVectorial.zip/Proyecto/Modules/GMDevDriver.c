#include <linux/init.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#define nombre_device_driver    "GMatrixDeviceDriver"
#define classname_device_driver "GMatrixDeviceDriverClass"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Steven, Daniela & Lester");
MODULE_DESCRIPTION("Modulo Device Driver");
MODULE_VERSION("1.0");

// Funciones del dispositivo
extern void aplicar_escala_de_grises(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB);
extern void aplicar_sepia(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB);
extern void aplicar_negativo(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB);
extern void aplicar_rotacion(char* srcX, char* srcY, char* dstX, char* dstY, int p1, int p2, int xfrom, int yfrom, int angle);
extern void aplicar_traslacion(char* srcX, char* srcY, char* dstX, char* dstY, int p1, int p2, int xdisplace, int ydisplace);
extern void aplicar_espejo(char* srcX, char* srcY, char* dstX, char* dstY, int p1, int p2, int x1, int y1, int x2, int y2);

// Identificador del modulo y candado de acceso
static int device_id;
static int device_syslock = 0;

// Punteros del device driver
static struct class*  device_driver_class  = NULL; 
static struct device* device_driver_ptr    = NULL; 

// Variables de llegada de mensajes de comunicacion
static char mensaje[2];
static int estado = 0;
static int transformacion = 0;
static int efecto = 0;

static int escrituras_pendientes = 0;
static int lecturas_pendientes = 0;

#define estado_parametros 0
#define estado_vectorial 1
#define estado_matricial 2

#define transformacion_rotacion 0
#define transformacion_traslacion 1
#define transformacion_espejo 2

#define efecto_grises 0
#define efecto_sepia 1
#define efecto_negativo 2

// intMsg sirve para recibir entero desde el userspace como 4 bytes consecutivos
static char intMsg[4];

// Variables de datos matriciales
static unsigned char pSource_R[3000000];
static unsigned char pSource_G[3000000];
static unsigned char pSource_B[3000000];
static unsigned char pDest_R[3000000];
static unsigned char pDest_G[3000000];
static unsigned char pDest_B[3000000];

// Variables de datos vectoriales
static unsigned char cSource_X[1000];
static unsigned char cSource_Y[1000];
static unsigned char cDest_X[1000];
static unsigned char cDest_Y[1000];

// Variable de tamaño
static int size = 0;

// ptr1 y 2, son desplazmientos que indican desde donde a donde, va la figura que se va a trabajar
static int ptr1;
static int ptr2;

// param, son parámetros adicionales a los vectores, como angulo, desplazamiento, etc
static int param1;
static int param2;
static int param3;
static int param4;

//De arreglo de 4 chars a entero de nuevo
extern int bytesToInt(char* bytes);

// Convierte un entero en un arreglo de 4 chars
extern void intToBytes(int n, char* bytes);

// Se llama cuando se lee en nuestro dispositivo (es decir, el device driver lee desde el user space)
static ssize_t device_driver_read(struct file *flip, char *buffer, size_t len, loff_t *offset) {
	
	if(escrituras_pendientes == 0){
		
		if(estado == estado_matricial){
			
			// En cada llamado envie al userspace las matrices ya con el efecto aplicado
			switch(lecturas_pendientes){
				case 3: 
					copy_to_user(buffer, pDest_R ,len); 
					printk(KERN_INFO "GMatrix Device Driver: El usuario esta leyendo del dispositivo bitmaps. Etapa 1/3"); 
					break;
				case 2: 
					copy_to_user(buffer, pDest_G ,len); 
					printk(KERN_INFO "GMatrix Device Driver: El usuario esta leyendo del dispositivo bitmaps. Etapa 2/3");
					break;
				case 1: 
					copy_to_user(buffer, pDest_B ,len);  
					printk(KERN_INFO "GMatrix Device Driver: El usuario esta leyendo del dispositivo bitmaps. Etapa 3/3");
					estado = estado_parametros;
					break;
			}
			lecturas_pendientes--; 
		
		}else if(estado == estado_vectorial){
			// En cada llamado envie al userspace los vectores ya con la transformacion aplicada
			switch(lecturas_pendientes){
				case 2:
					copy_to_user(buffer, cDest_X ,len); 
					printk(KERN_INFO "GMatrix Device Driver: El usuario esta leyendo del dispositivo vectores. Etapa 1/2");
					break;
				case 1: 
					copy_to_user(buffer, cDest_Y ,len);  
					printk(KERN_INFO "GMatrix Device Driver: El usuario esta leyendo del dispositivo vectores. Etapa 2/2");
					estado = estado_parametros;
					break;
			}
			lecturas_pendientes--; 
			
		}
		
	}else{
		// Aun no completo el envio de las datos originales, por lo que no puede enviar las respuesta de los efectos o transformaciones
		printk(KERN_INFO "GMatrix Device Driver: No se puede enviar una respuesta si el dispostivo aun esta esperando datos primero.");	
	}
	
	return 0;
		
}

// Se llama cuando se escribe en nuestro dispositivo (es decir, el kernel escribe en el user space)
static ssize_t device_driver_write(struct file *flip, const char *buffer, size_t len, loff_t *offset) {
	
	// EL kernel primero necesita saber que va recibir, asi que el espera primero los parametros en un primer call
	if (estado == estado_parametros){
		copy_from_user(mensaje, buffer, len);
		
		// Primero reciba los parametros y decodifique su instrucción
		char tipo        = mensaje[0];
		char filtro      = mensaje[1];
		
		// Digalo para proposito de debugging
		printk(KERN_INFO "GMatrix Device Driver: Se ha colocado el modo %c con el efecto/transformacion %c. \n", tipo, filtro);
		
		// Serán vectores
		if (tipo == '0'){
			
			estado = estado_vectorial;
			escrituras_pendientes = 8;
			
			// Ahora con esto el modulo ya sabe que transformacion va aplicar y que datos va recibir del usuario
			switch(filtro){
				case '0': transformacion = transformacion_rotacion; 
					break;
				case '1': transformacion = transformacion_traslacion; 
					break;
				case '2': transformacion = transformacion_espejo; 
					break;
			}
			
		// Serán bitmaps
		}else{
			
			estado = estado_matricial;
			escrituras_pendientes = 3;
			
			// Ahora con esto el modulo ya sabe que efecto va aplicar y que datos va recibir del usuario
			switch(filtro){
				case '0': efecto = efecto_grises; break;
				case '1': efecto = efecto_sepia; break;
				case '2': efecto = efecto_negativo; break;
			}
			
		}
		
	}else if (estado == estado_vectorial){
		
		// Transformaciones en vectoriales
		// Todas las transformaciones reciben (srcX, srcY, dstX, dstY) pero lo hacen en diferente 
		
		switch(escrituras_pendientes){
			case 8: 
				size = len;
				copy_from_user(cSource_X, buffer, len); 
				copy_from_user(cDest_X, buffer, len); 
				printk(KERN_INFO "GMatrix Device Driver: %d", len);
				printk(KERN_INFO "GMatrix Device Driver: El usuario esta escribiendo vectores al dispositivo. Etapa 1/2.");
				break;
			case 7: 
				copy_from_user(cSource_Y, buffer, len); 
				copy_from_user(cDest_Y, buffer, len); 
				printk(KERN_INFO "GMatrix Device Driver: El usuario esta escribiendo vectores al dispositivo. Etapa 2/2.");
				break;
			case 6: 
				copy_from_user(intMsg, buffer, len); 
				ptr1 = bytesToInt(intMsg);
				printk(KERN_INFO "GMatrix Device Driver: El usuario esta escribiendo el punto de inicio de la figura. (%d)", ptr1);
				break;
			case 5: 
				copy_from_user(intMsg, buffer, len); 
				ptr2 = bytesToInt(intMsg);
				printk(KERN_INFO "GMatrix Device Driver: El usuario esta escribiendo el punto de fin de la figura. (%d)", ptr2);
				break;
			case 4: 
				copy_from_user(intMsg, buffer, len); 
				param1 = bytesToInt(intMsg);
				printk(KERN_INFO "GMatrix Device Driver: El usuario esta escribiendo el parametro de transformacion 1 de 4 (%d)", param1);
				break;
			case 3: 
				copy_from_user(intMsg, buffer, len); 
				param2 = bytesToInt(intMsg);
				printk(KERN_INFO "GMatrix Device Driver: El usuario esta escribiendo el parametro de transformacion 2 de 4 (%d)", param2);
				break;
			case 2: 
				copy_from_user(intMsg, buffer, len); 
				param3 = bytesToInt(intMsg);
				printk(KERN_INFO "GMatrix Device Driver: El usuario esta escribiendo el parametro de transformacion 3 de 4 (%d)", param3);
				break;
			case 1: 
				copy_from_user(intMsg, buffer, len); 
				param4 = bytesToInt(intMsg);
				printk(KERN_INFO "GMatrix Device Driver: El usuario esta escribiendo el parametro de transformacion 4 de 4 (%d)", param4);
				
				// Cuando ya tiene todas las matrices, llame al otro modulo para hacer el efecto
				switch(transformacion){
					case transformacion_rotacion:  
						aplicar_rotacion(cSource_X, cSource_Y, cDest_X, cDest_Y, ptr1, ptr2, param1, param2, param3); 
					break;
					case transformacion_traslacion: 
						aplicar_traslacion(cSource_X, cSource_Y, cDest_X, cDest_Y, ptr1, ptr2, param1, param2); 
						break;
					case transformacion_espejo:  
						aplicar_espejo(cSource_X, cSource_Y, cDest_X, cDest_Y, ptr1, ptr2, param1, param2, param3, param4); 
						break;
				}
				
				lecturas_pendientes = 2; 
				break;
		}
		escrituras_pendientes--; 
		
	}else if (estado == estado_matricial){
	
		// Efectos en bitmaps
		// Comienza a recibir en cada llamado una matriz de color
		switch(escrituras_pendientes){
			case 3: 
				copy_from_user(pSource_R, buffer, len); 
				printk(KERN_INFO "GMatrix Device Driver: El usuario esta escribiendo bitmaps al dispostivo. Etapa 1/3.");
				break;
			case 2: 
				copy_from_user(pSource_G, buffer, len); 
				printk(KERN_INFO "GMatrix Device Driver: El usuario esta escribiendo bitmaps al dispostivo. Etapa 2/3.");
				break;
			case 1: 
				copy_from_user(pSource_B, buffer, len); 
				printk(KERN_INFO "GMatrix Device Driver: El usuario esta escribiendo bitmaps al dispostivo. Etapa 3/3.");
					
				// Cuando ya tiene todas las matrices, llame al otro modulo para hacer el efecto
				switch(efecto){
					case efecto_grises: aplicar_escala_de_grises(pSource_R, pSource_G, pSource_B, pDest_R, pDest_G, pDest_B); break;
					case efecto_sepia: aplicar_sepia(pSource_R, pSource_G, pSource_B, pDest_R, pDest_G, pDest_B); break;
					case efecto_negativo: aplicar_negativo(pSource_R, pSource_G, pSource_B, pDest_R, pDest_G, pDest_B); break;
				}
				
				lecturas_pendientes = 3; 
				break;
		}
		escrituras_pendientes--; 
			
	}
	
	return 0;
}

// Se llama cuando se abre el dispositivo (se abre el archivo en /dev/)
static int device_driver_abierto(struct inode *inode, struct file *file) {
	device_syslock++;
	printk(KERN_INFO "GMatrix Device Driver: Dispositivo abierto desde el userspace. \n");
	
	return 0;
}

// Se llama cuando se cierra el dispositivo (se cierra el archivo en /dev/)
static int device_driver_liberar(struct inode *inode, struct file *file) {
	device_syslock--;
	printk(KERN_INFO "GMatrix Device Driver: Dispositivo cerrado desde el userspace. \n");
	
	return 0;
}

// Punteros a las funciones del device driver
static struct file_operations operaciones_principales = {
	.read = device_driver_read,
	.write = device_driver_write,
	.open = device_driver_abierto,
	.release = device_driver_liberar
};

// Funcion de carga del modulo al Kernel
static int __init device_driver_cargado(void) {
	 
	// Registre el identificador del modulo
	device_id = register_chrdev(0, nombre_device_driver, &operaciones_principales);
	 
	if (device_id < 0) {
		printk(KERN_ALERT "GMatrix Device Driver: No se pudo cargar el dispositivo. \n");
		return device_id;
	}else{
		printk(KERN_INFO "GMatrix Device Driver: Modulo ha sido cargado correctamente. (ID: %d) \n", device_id);
	}
	
	// Cree la clase dinamica que contendra al modulo
	device_driver_class = class_create(THIS_MODULE, classname_device_driver);
	if(IS_ERR(device_driver_class)){
		unregister_chrdev(device_id, nombre_device_driver);
		printk(KERN_ALERT "GMatrix Device Driver: Error al crear la clase del dispositivo. \n");
		return PTR_ERR(device_driver_class);
	}
	printk(KERN_INFO "GMatrix Device Driver: Clase del dispositivo creada correctamente. \n");
	
	// Ahora si, cree el archivo del dispositivo en /dev/ ahora que ya tenemos todo lo necesario
	device_driver_ptr = device_create(device_driver_class, NULL, MKDEV(device_id, 0), NULL, nombre_device_driver);
	if (IS_ERR(device_driver_ptr)){
		class_destroy(device_driver_class);
		unregister_chrdev(device_id, nombre_device_driver);
		printk(KERN_ALERT "GMatrix Device Driver: Error al crear el dispositivo. \n");
		return PTR_ERR(device_driver_ptr);
	}
	printk(KERN_INFO "GMatrix Device Driver: Dispositivo listo para utilizar desde el userspace. \n");
	return 0;
}

// Funcion de descarga del Kernel
static void __exit device_driver_descargado(void) {
	device_destroy(device_driver_class, MKDEV(device_id, 0));     
	class_unregister(device_driver_class);                          
	class_destroy(device_driver_class);                             
	unregister_chrdev(device_id, nombre_device_driver);
	printk(KERN_INFO "GMatrix Device Driver: Modulo ha sido descargado correctamente. (ID: %d) \n", device_id);
}

// Punteros a las funciones de carga y descarga
module_init(device_driver_cargado);
module_exit(device_driver_descargado);
