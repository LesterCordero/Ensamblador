#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern void modCifrado(char* hilera, int a, int b, int m);

// Encuentre que x satisface (n * x mod m) = 1 (inverso modular)
int inversoMult(int n, int m){
	for(int x=1; x<m; x++){
		if((n*x)%m == 1){
			return x;
		}
	}
}

// Encuentre que x satisface (n + x) mod m = 0 (inverso aditivo)
int inversoAdd(int n, int m){
	for(int x=1; x<m; x++){
		if((n+x)%m == 0){
			return x;
		}
	}
}

// Una vez encontrandos ambos inversos, asegurese que su multplicación no exceda el modulo
int completeFormula(int a, int b, int m){
	return (a*b)%m;
}

int main(){

	// Cree punteros iniciales
	FILE *archivo_original;
	FILE *archivo_encriptado;
	FILE *archivo_desencriptado;
	
	// Carge el archivo de entrada y salida en su respectivo modo
	archivo_original = fopen("liebre.txt","r");
	archivo_encriptado = fopen("liebre_protegido.txt","w+");
	archivo_desencriptado = fopen("liebre_desencriptado.txt","w");
		
	// Si no cargo los archivos entonces falle
	if(archivo_original == NULL || archivo_encriptado == NULL || archivo_desencriptado == NULL){
		printf("Error al cargar el archivo original o durante la creacion de los archivos de salida.\n");
		return -1;
	}
	
	// Obtenga el final del archivo
	long tamArchivo;
	fseek(archivo_original, 0L, SEEK_END);
	tamArchivo = ftell(archivo_original);
	rewind(archivo_original);
	
	// Prepare una hilera con el mismo numero de bytes que el archivo leido
	char* hileraCompleta = calloc(1, tamArchivo+1);
	fread(hileraCompleta, tamArchivo, 1, archivo_original);

	// Cree las llaves publicas y privadas
	int modulo = 127;
	int a_publica = 6;
	int b_publica = 9;
	int a_privada = inversoMult(a_publica, modulo);
	int b_privada = completeFormula(a_privada,inversoAdd(b_publica, modulo),modulo);
	
	// Encripte	
	printf("Se va a encriptar con aritmetica modular (LLave publica K = (%i, %i, %i))\n", a_publica, b_publica, modulo);
	modCifrado(hileraCompleta, a_publica, b_publica, modulo);
	fputs(hileraCompleta, archivo_encriptado);
	
	// Desencripte	
	printf("Se va a desencriptar con aritmetica modular (LLave privada R = (%i, %i, %i))\n", a_privada, b_privada, modulo);
	modCifrado(hileraCompleta, a_privada, b_privada, modulo);
	fputs(hileraCompleta, archivo_desencriptado);

	// Libere la memoria
	fclose(archivo_original);
	fclose(archivo_encriptado);
	fclose(archivo_desencriptado);
	free(hileraCompleta);
	
	// Termine el programa
	printf("El programa ha terminado exitosamente.\n");
	return 0;
		
}
