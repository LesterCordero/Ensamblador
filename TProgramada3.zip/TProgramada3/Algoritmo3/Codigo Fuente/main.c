#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern void bytePermut(char* hilera, int semilla, int bytesNum);

int inversoMult(int n, int m){
	// Si n > m, entonces reduzcalo a otro n que sea menor pero congruente
	n = n%m; 

	// Encuentre que x satisface a * x mod m = 1 ( inverso modular)
	for(int x=1; x<m; x++){
		if((n*x)%m == 1){
			return x;
		}
	}

	//Euclides tambien sirve para encontrar este valor
}

int main(){
	
	// Cree punteros iniciales
	FILE *archivo_original;
	FILE *archivo_encriptado;
	FILE *archivo_desencriptado;
	
	// Carge el archivo de entrada y salida en su respectivo modo
	archivo_original = fopen("liebre.txt","r");
	archivo_encriptado = fopen("liebre_protegido.txt","w+");
	archivo_desencriptado = fopen("liebre_desencriptado.txt","w");
		
	// Si no cargo los archivos entonces falle
	if(archivo_original == NULL || archivo_encriptado == NULL || archivo_desencriptado == NULL){
		printf("Error al cargar el archivo original o durante la creacion de los archivos de salida.\n");
		return -1;
	}
	
	// Obtenga el final del archivo
	long tamArchivo;
	fseek(archivo_original, 0L, SEEK_END);
	tamArchivo = ftell(archivo_original);
	rewind(archivo_original);
	
	// Prepare una hilera con el mismo numero de bytes que el archivo leido
	char* hileraCompleta = calloc(1, tamArchivo+1);
	fread(hileraCompleta, tamArchivo, 1, archivo_original);

	// LLave Publica
	int a = 3;
	int b = 2;
	int m = 11;
	printf("Si Publica = (%i, %i, %i) entonces Privada = (%i, %i, %i) \n", a, b, m, inversoMult(a, m), b, m);

	/*
	// Encripte	
	printf("Se va a encriptar con permutacion de bytes el archivo de prueba (LLave de encriptacion: %i)\n", llaveEncriptado);
	bytePermut(hileraCompleta, llaveEncriptado, tamArchivo);
	fputs(hileraCompleta, archivo_encriptado);
	
	// Desencripte	
	printf("Se va a desencriptar con permutacion de bytes el archivo de prueba (LLave de desencriptacion: %i)\n", llaveDesencriptado);
	bytePermut(hileraCompleta, llaveDesencriptado, tamArchivo);
	
	fputs(hileraCompleta, archivo_desencriptado);*/

	printf("El programa ha terminado exitosamente.\n");

	fclose(archivo_original);
	fclose(archivo_encriptado);
	fclose(archivo_desencriptado);
	free(hileraCompleta);
	return 0;
		
}
