#include <linux/module.h>
MODULE_LICENSE("GPL-2");

extern void _asm_E1(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB, int charNumbers);

static void aplicar_escala_de_grises(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB, int charNumbers){

		// Llama a la funcion ensamblador y le aplica un efecto matricial utilizando SSE2
		_asm_E1(srcR, srcG, srcB, dstR, dstG, dstB, charNumbers);
		
}

static void aplicar_sepia(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB, int charNumbers){
	
}

static void aplicar_negativo(unsigned char* srcR, unsigned char* srcG, unsigned char* srcB, unsigned char* dstR, unsigned char* dstG, unsigned char* dstB, int charNumbers){
	
}

// Exporte los simbolos
EXPORT_SYMBOL(aplicar_escala_de_grises);
EXPORT_SYMBOL(aplicar_sepia);
EXPORT_SYMBOL(aplicar_negativo);
EXPORT_SYMBOL(_asm_E1);

static int __init device_cargado(void) {
	printk(KERN_INFO "GMatrix Device: Dispositivo listo para utilizar desde el driver. \n");
	return 0;
}


static void __exit device_descargado(void) {
	printk(KERN_INFO "GMatrix Device: Dispositivo ha sido descargado correctamente.\n");
}

// Punteros a las funciones de carga y descarga
module_init(device_cargado);
module_exit(device_descargado);
