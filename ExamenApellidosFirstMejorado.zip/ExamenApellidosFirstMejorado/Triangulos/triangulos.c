#include <stdio.h>

extern int esTriangulo (int a, int b, int c);

int main()
{
   int a, b, c;
   int result;
   
   while (1) {
      printf("Digite tres valores enteros: ");
      scanf("%d %d %d", &a, &b, &c);
      printf("Leido: (%d, %d, %d). ", a, b, c);
      result = esTriangulo (a, b, c);
      
      if (result) printf("Las medidas SI forman un triangulo.\n\n");
      else        printf("Las medidas NO forman un triangulo.\n\n");
   }
}


