#include <iostream>
#include <string>
#include <GL/glut.h>
#include "EasyBMP/EasyBMP.h"
using namespace std;

// Author: LESTER CORDERO MURILLO

// Defino byte puro
typedef unsigned char byte;

// Prepare los parametros de la ventana
char titulo[] = "Ejemplo de OpenGL para Proyecto Integrador";
int largo = 0;
int altura = 0;

int foto_x = 0;
int foto_y = 0;

// Matriz de bytes de color
byte** matrizRojo;
byte** matrizVerde;
byte** matrizAzul;

// Pide devolver callblack mediante puntero nulo
void renderizar(void)
{
	// Cambie el color de fondo a RGBA(255,255,255,255)
    glClearColor(1.0,1.0,1.0,1.0);
    
    // Apliqueselo a el buffer de color de la ventana
    glClear(GL_COLOR_BUFFER_BIT);
    
    // Indique que es una proyeccion 2D
    glMatrixMode(GL_PROJECTION);
    
    // Cargue la identidad
    glLoadIdentity();
    gluOrtho2D(0, largo, altura, 0);
    
    // Cambie el color de dibujado
    glBegin(GL_POINTS);
    for(int x = 0; x < foto_x; x++){
		for(int y = 0; y < foto_y; y++){
			// Renderize el rojo
			glColor3ub(matrizRojo[x][y],0,0);
			glVertex2i(x+20,y+20);
			
			// Renderize el verde
			glColor3ub(0,matrizVerde[x][y],0);
			glVertex2i(x+foto_x+40,y+20);
			
			// Renderize el azul
			glColor3ub(0,0,matrizAzul[x][y]);
			glVertex2i(x+20,y+foto_y+40);
			
			// Renderize todo junto
			glColor3ub(matrizRojo[x][y],matrizVerde[x][y],matrizAzul[x][y]);
			glVertex2i(x+foto_x+40,y+foto_y+40);
		}
	}
    
    // Termine el dibujado
    glEnd();
    
    // Fuerza que los comandos de OpenGL sean finitos, y borra los buffers
    glFlush();
}

void construyeMatrizRGB(int largo_x, int altura_y){
	// Construya la matriz
	matrizRojo = new byte*[largo_x];
	matrizVerde = new byte*[largo_x];
	matrizAzul = new byte*[largo_x];
	for(int i = 0; i < largo_x; ++i){
		matrizRojo[i] = new byte[altura_y];
		matrizVerde[i] = new byte[altura_y];
		matrizAzul[i] = new byte[altura_y];
	}
}

void destruyeMatrizRGB(int largo_x, int altura_y){
	// Destruya la matriz
	for(int i = 0; i < largo_x; ++i){
		delete[] matrizRojo[i];
		delete[] matrizVerde[i];
		delete[] matrizAzul[i];
	}
	
	delete[] matrizRojo;
	delete[] matrizVerde;
	delete[] matrizAzul;
}

int main(int argc, char** argv)
{
	// Entrada del archivo BMP
	string archivo;
	cout << "Escriba el nombre del archivo BMP a cargar, incluya extension." << endl;
	cin >> archivo;
	
	// Cargue la imagen desde BMP a C

    BMP Image;
	Image.ReadFromFile(archivo.c_str());
	
    foto_x = Image.TellWidth();
    foto_y = Image.TellHeight();
    
    // Ahora ajuste la ventana que se creara para que tenga el tamaño correcto
    
    largo = foto_x*2 + 60;
    altura = foto_y*2 + 60;
    
	// Inicie OpenGL usando freeglut como API
    glutInit(&argc, argv);
    
    // GLUT_SINGLE indica que la ventana es de un buffer
    glutInitDisplayMode(GLUT_SINGLE); 
    
    // Centre la ventana
	int posicionX = ((glutGet(GLUT_SCREEN_WIDTH)-largo)/2);
	int posicionY = ((glutGet(GLUT_SCREEN_HEIGHT)-altura)/2);

    // Pase los parametros
    glutInitWindowSize(largo, altura);
    glutInitWindowPosition(posicionX, posicionY);
    glutCreateWindow(titulo);
    
    // Cree matriz RGB que pueden ser modificadas desde ASM
    construyeMatrizRGB(foto_x,foto_y);
    
    // Despues de leerlo, paselo de formato BMP a formato de matriz de C
	for( int x=0 ; x < Image.TellWidth() ; x++){
		for( int y=0 ; y < Image.TellHeight() ; y++){
			matrizRojo[x][y] = Image(x,y)->Red;
			matrizVerde[x][y] = Image(x,y)->Green;
			matrizAzul[x][y] = Image(x,y)->Blue;
		}
	}
	
	// AQUI INSERTE SU CODIGO QUE TRANSFORMA DESDE ENSAMBLADOR
	// ......
	// UTILIZE SSE para aplicar cambios a toda la matriz simultaneamente
   
    // Defina las funciones del usuario
    glutDisplayFunc(renderizar);
    
    // Inicie la ventana
    glutMainLoop();
    
    // Termine el programa
    destruyeMatrizRGB(foto_x,foto_y);
    return 0;
}
